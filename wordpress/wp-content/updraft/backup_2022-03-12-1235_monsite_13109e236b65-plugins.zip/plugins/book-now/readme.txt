=== Book Now ===
Contributors: riangraphics
Donate link: http://www.riangraphics.com/book-now/
Tags: fixed buttons, call to action buttons, book now, call me button, buttons, call to action fixed button
Requires at least: 3.5
Tested up to: 5.3
Stable tag: 5.3
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin, Book Now adds a fixed call to action button to your site, with text and link to anywhere you want.

== Description ==

This plugin, Book Now adds a fixed call to action button to your site, with text and link to anywhere you want.

*Easy call to action button*
Book Now is a plugin to help you create a cool looking fixed call to action button, spread across all yuor website pages.

*Easy to setup*
Book Now has a nice and clean settings page, to help you customize your button with simple options.

Check out official page for Book Now [RianGraphics](http://www.riangraphics.com/book-now/ "Easy Call to Action Butons")

A few notes about the sections above:

*   "Contributors" riangraphics
*   "Tags" fixed buttons, call to action buttons, book now, call me button, buttons, call to action fixed button
*   "Requires at least" 3.5
*   "Tested up to" 5.3
*   "trunk"

== Installation ==

Book Now can be installed like any other wordpress plugin.

e.g.

1. Upload the plugin files to the '/wp-content/plugins/book-now' directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Book Now screen to configure the plugin


== Frequently Asked Questions ==

= Is this a complicated plugin to use? =

Absolutely not, Book Now is an easy to use plugin.

== Screenshots ==

1. 'Book Now in Action'
2. 'Book Now settings page'

== Changelog ==
= 1.5 =
* Added font family option
* Fixed some bugs

= 1.4.4 =
* Added font size option

= 1.3.7 =
* Added target option

= 1.2.6 =
* Fixing bugs

= 1.2.5 =
* Fixing bugs

= 1.2.4 =
* Visual fixes

= 1.2.3 =
* Added WPML Support

= 1.2.2 =
* Fixed some bugs

= 1.2.1 =
* Fixed some bugs

= 1.2 =
* Added Text Color option.

= 1.1 =
* Testing out some WordPress stuff.

= 1.0 =
* first release of Book Now WordPress Plugin.

== Upgrade Notice ==

= 1.3.7 =
* Added target option

= 1.2.6 =
* Fixing bugs

= 1.2.5 =
* Fixing bugs

= 1.2.4 =
* Visual fixes

= 1.2.3 =
* Added WPML Support

= 1.2.2 =
* Fixed some bugs

= 1.2.1 =
* Fixed some bugs

= 1.2 =
* This Release added the Text Color Option to the plugin settings page.

= 1.1 =
This is the release version use this for now anything has been touched.

= 1.0 =
This is the release version use this for now.

== Arbitrary section ==

Nothing to say.
